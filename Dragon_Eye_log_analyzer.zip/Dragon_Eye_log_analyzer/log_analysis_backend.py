import re
import json
import csv
import requests
from collections import defaultdict

# Step 1: Read Log File
def read_log_file(file_path):
    """Reads a log file and returns its contents."""
    try:
        with open(file_path, 'r') as file:
            return file.readlines()
    except FileNotFoundError:
        print("Log file not found.")
        return []

# Step 2: Parse Logs
def parse_logs(logs):
    """Parses log entries to extract fields."""
    parsed_logs = []
    log_pattern = r'(\d+\.\d+\.\d+\.\d+) - - \[(.+)\] "(.+)" (\d+) (\d+|-)'
    for log in logs:
        match = re.match(log_pattern, log)
        if match:
            ip, timestamp, request, status_code, size = match.groups()
            parsed_logs.append({
                'ip': ip,
                'timestamp': timestamp,
                'request': request,
                'status_code': status_code,
                'size': size
            })
    return parsed_logs

# Step 3: Detect Brute Force
def detect_brute_force(parsed_logs):
    """Detects brute force attempts by flagging repeated failed login attempts."""
    ip_counts = defaultdict(int)
    for log in parsed_logs:
        ip_counts[log['ip']] += 1
    return [ip for ip, count in ip_counts.items() if count > 10]  # Threshold: 10 requests

# Step 4: Detect SQL Injection
def detect_sql_injection(parsed_logs):
    """Detects potential SQL injection attempts in the request."""
    sql_pattern = r"('|\"|;|\\bSELECT\\b|\\bDROP\\b|\\bINSERT\\b|\\bDELETE\\b)"
    suspicious_requests = [log for log in parsed_logs if re.search(sql_pattern, log['request'], re.IGNORECASE)]
    return suspicious_requests

# Step 5: Generate Report
def generate_report(brute_force_ips, sql_injection_logs, format_type):
    """Generates a summary report of findings."""
    report = {
        "brute_force_ips": brute_force_ips,
        "sql_injection_logs": sql_injection_logs
    }

    if format_type == "json":
        with open("report.json", "w") as file:
            json.dump(report, file, indent=4)
        return "report.json"
    elif format_type == "csv":
        with open("report.csv", "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Brute Force IPs"])
            writer.writerows([[ip] for ip in brute_force_ips])
            writer.writerow(["SQL Injection Logs"])
            for log in sql_injection_logs:
                writer.writerow([log])
        return "report.csv"
    elif format_type == "txt":
        with open("report.txt", "w") as file:
            file.write("Brute Force IPs:\n")
            file.writelines(f"{ip}\n" for ip in brute_force_ips)
            file.write("\nSQL Injection Logs:\n")
            file.writelines(f"{log}\n" for log in sql_injection_logs)
        return "report.txt"
    else:
        return None

