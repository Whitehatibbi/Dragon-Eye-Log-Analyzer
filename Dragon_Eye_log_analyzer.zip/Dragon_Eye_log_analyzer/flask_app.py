from flask import Flask, request, jsonify, render_template
import os

# Import backend functions
from log_analysis_backend import read_log_file, parse_logs, detect_brute_force, detect_sql_injection, generate_report

app = Flask(__name__)

# Route: Home
@app.route("/")
def home():
    return render_template("index.html")  # Render the HTML UI

# Route: Upload Log File
@app.route("/upload", methods=["POST"])
def upload_log():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    # Save the uploaded file
    file_path = os.path.join("uploads", file.filename)
    file.save(file_path)

    # Process the log file
    logs = read_log_file(file_path)
    parsed_logs = parse_logs(logs)
    brute_force_ips = detect_brute_force(parsed_logs)
    sql_injection_logs = detect_sql_injection(parsed_logs)

    # Generate report based on selected format
    format_type = request.form.get("format")
    if format_type == "json":
        report = generate_report(brute_force_ips, sql_injection_logs, "json")
        return jsonify({"message": "Analysis complete.", "report": report})
    elif format_type == "csv":
        report = generate_report(brute_force_ips, sql_injection_logs, "csv")
        return jsonify({"message": "Analysis complete. Report generated as report.csv"})
    elif format_type == "txt":
        report = generate_report(brute_force_ips, sql_injection_logs, "txt")
        return jsonify({"message": "Analysis complete. Report generated as report.txt"})
    elif format_type == "screen":
        return render_template("report.html", brute_force_ips=brute_force_ips, sql_injection_logs=sql_injection_logs)
    else:
        return jsonify({"error": "Invalid format selected"}), 400

# Run the Flask app
if __name__ == "__main__":
    if not os.path.exists("uploads"):
        os.makedirs("uploads")  # Create a folder to store uploaded logs
    app.run(debug=True)
